package company.common;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        double x = console.nextDouble();
        double a = -8.750;
        double z = 0.765;
        double y = 0;
        if(x<=1)
            y = a + (x/(a+x*x*x));
        if(x>1)
            y = Math.pow(1+Math.tan(z/2)*Math.tan(z/2),Math.sqrt(Math.abs(a)+6));
        System.out.println("y = "+y);
    }
}
