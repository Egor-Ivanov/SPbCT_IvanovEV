package company.common;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        int k = console.nextInt();
        if(k>=91 && k<=100)
            System.out.println("Соответствующий разряд - A");
        if(k>=81 && k<=90)
            System.out.println("Соответствующий разряд - B");
        if(k>=71 && k<=80)
            System.out.println("Соответствующий разряд - C");
        if(k>=61 && k<=70)
            System.out.println("Соответствующий разряд - D");
        if(k>=51 && k<=60)
            System.out.println("Соответствующий разряд - E");
        if(k<=50)
            System.out.println("Соответствующий разряд - F");
    }
}