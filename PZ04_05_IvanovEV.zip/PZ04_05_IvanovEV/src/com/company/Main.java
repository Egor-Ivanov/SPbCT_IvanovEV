package com.company;
import java.util.Scanner;

public class Main {
   public static void oddEvenSort(int arr[], int n)
    {
        boolean isSorted = false; // Изначально массив не отсортирован

        while (!isSorted)
        {
            isSorted = true;
            int temp =0;

            //Выполнить пузырьковую сортировку для нечетного индексированного элемента
            for (int i=1; i<=n-2; i=i+2)
            {
                if (arr[i] > arr[i+1])
                {
                    temp = arr[i];
                    arr[i] = arr[i+1];
                    arr[i+1] = temp;
                    isSorted = false;
                }
            }

            // Выполнить пузырьковую сортировку для четного индексированного элемента
            for (int i=0; i<=n-2; i=i+2)
            {
                if (arr[i] > arr[i+1])
                {
                    temp = arr[i];
                    arr[i] = arr[i+1];
                    arr[i+1] = temp;
                    isSorted = false;
                }
            }
        }

        return;
    }
    public static void main (String[] args)
    {
        int n = 20;
        int arr[] = new int[n];
        System.out.print("Исходный массив:\n");
        for (int i = 0; i < n; i++) {
            arr[i] = (int) Math.round((Math.random() * 30));
            System.out.print(arr[i] + " ");
        }
        System.out.print("\n");
        System.out.print("Отсортированный массив:\n");
        oddEvenSort(arr, n);
        for (int i=0; i < n; i++)
            System.out.print(arr[i] + " ");
            System.out.println(" ");
    }
}
