package com.company;

public class Main {

    public static void main(String[] args) {
    int a = 4554;
    if(a%10 == a/1000 && a%100/10 == a%1000/100){
        System.out.println("yes");
    }else {
        System.out.println("no");
    }
    }
}
