package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int input = 0;
        int sum =0;

        System.out.print("Enter a series of values (0 to quit): ");
        Scanner in = new Scanner(System.in);

        while ((input = in.nextInt()) != 0) {
            sum = sum+input;
        }
        System.out.println(sum);
    }
}
