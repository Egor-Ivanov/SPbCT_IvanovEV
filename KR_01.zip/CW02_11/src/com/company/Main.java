package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner scanner1 = new Scanner(System.in);
        System.out.println("Введите количество дней");
        int days = scanner1.nextInt();

        Scanner scanner2= new Scanner(System.in);
        System.out.println("Введите процент скидки");
        double sale = scanner2.nextDouble();

        Scanner scanner3= new Scanner(System.in);
        System.out.println("Введите сумму");
        double sum = scanner3.nextDouble();

        sale /= 100;
        for(int i = 0; i < days; i++){
            sum += 3;
            sum += sum * sale;
        }
        System.out.println(sum);
    }
}
