package com.company;

public class Main {

    public static void main(String[] args) {
	int d = 0;
	for(char i = 'a'; i <= 'z'; i++){
	    //System.out.print(d%5 == 0 && d!=0 ? "\n" : i);
	    //d++;
		d++;
		if (d%5!=0){
			System.out.print(i);
		}else {
			System.out.println(i);
		}
    }
    }
}
