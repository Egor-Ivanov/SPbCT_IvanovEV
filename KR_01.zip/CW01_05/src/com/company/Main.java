package com.company;

public class Main {

    public static void main(String[] args) {
	int a;
	a = 1+2-4;
	System.out.println(a);
    }
}
