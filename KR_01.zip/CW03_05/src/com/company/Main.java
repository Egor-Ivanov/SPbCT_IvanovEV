package com.company;

public class Main {

    public static void main(String[] args) {
        int a = 100;
        int b = 1000;



        if (Math.abs(a-b) == 100) {
            System.out.println("Yes");
        }else {
            System.out.println("No");
        }
    }
}
