package com.company;

public class Main {

    public static void main(String[] args) {
	int i = 1001;
	while ( i <= 1025 ){
        System.out.println(i);
	    i++;
    }
    }
}
